// settings.js — controls the Geo glass-tuning sliders, accent color, and
// browsing prefs. There's no light/dark "Appearance" switch: the frosted
// glass look is always on, but its accent color is fully user-changeable
// (presets or a custom color picker) — see applyAccent() below.

const Settings = (() => {
  const STORAGE_KEY = "geo:settings";

  const PRESET_NAMES = {
    "#22c55e": "Earth Glass",
    "#3d8bff": "Ocean Glass",
    "#8b5cf6": "Violet Glass",
    "#f97316": "Sunset Glass",
  };

  const defaults = {
    blur: 34,
    opacity: 30,
    radius: 20,
    accentColor: "#3d8bff",
    searchEngine: "https://html.duckduckgo.com/html/?q=",
    homepage: "geo://start",
    searchSuggestions: true,
    restoreSession: false,
    reduceMotion: false,
  };

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? { ...defaults, ...JSON.parse(raw) } : { ...defaults };
    } catch {
      return { ...defaults };
    }
  }

  function save(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function hexToRgb(hex) {
    const clean = hex.replace("#", "");
    const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
    const n = parseInt(full, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function rgbToHex([r, g, b]) {
    return "#" + [r, g, b].map((c) => Math.max(0, Math.min(255, c)).toString(16).padStart(2, "0")).join("");
  }

  function darken(rgb, amt) {
    return rgb.map((c) => Math.round(c * (1 - amt)));
  }

  function themeName(hex) {
    return PRESET_NAMES[hex.toLowerCase()] || "Custom Glass";
  }

  function applyAccent(hex) {
    const rgb = hexToRgb(hex);
    const strong = rgbToHex(darken(rgb, 0.28));
    const root = document.documentElement.style;
    root.setProperty("--accent", hex);
    root.setProperty("--accent-strong", strong);
    root.setProperty("--accent-soft", `rgba(${rgb.join(",")}, 0.35)`);
    root.setProperty("--accent-glow", `rgba(${rgb.join(",")}, 0.55)`);
  }

  function apply(state) {
    const root = document.documentElement.style;
    root.setProperty("--glass-blur", `${state.blur}px`);
    root.setProperty("--glass-blur-soft", `${Math.max(6, state.blur * 0.6)}px`);
    root.setProperty("--glass-opacity", (state.opacity / 100).toFixed(2));
    root.setProperty("--glass-opacity-strong", Math.min(0.9, state.opacity / 100 + 0.16).toFixed(2));
    root.setProperty("--radius", `${state.radius}px`);
    root.setProperty("--radius-sm", `${Math.max(6, state.radius * 0.6)}px`);
    document.documentElement.dataset.reduceMotion = state.reduceMotion ? "true" : "false";
    applyAccent(state.accentColor);
  }

  let state = load();
  const listeners = [];
  // Exposed panel control hooks (populated in init)
  let openPanelFn = () => {};
  let closePanelFn = () => {};

  function updateThemeBadge() {
    const badge = document.getElementById("theme-badge");
    if (badge) badge.textContent = themeName(state.accentColor);
  }

  function updateSwatchActive() {
    document.querySelectorAll("#opt-accent-swatches .swatch[data-color]").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.color.toLowerCase() === state.accentColor.toLowerCase());
    });
  }

  function init() {
    apply(state);
    updateThemeBadge();

    const blur = document.getElementById("opt-blur");
    const blurVal = document.getElementById("opt-blur-val");
    const opacity = document.getElementById("opt-opacity");
    const opacityVal = document.getElementById("opt-opacity-val");
    const radius = document.getElementById("opt-radius");
    const radiusVal = document.getElementById("opt-radius-val");
    const search = document.getElementById("opt-search");
    const home = document.getElementById("opt-home");
    const suggestions = document.getElementById("opt-suggestions");
    const restore = document.getElementById("opt-restore");
    const reduceMotion = document.getElementById("opt-reduce-motion");
    const clearData = document.getElementById("opt-clear-data");
    const customColor = document.getElementById("opt-accent-custom");

    blur.value = state.blur;
    opacity.value = state.opacity;
    radius.value = state.radius;
    search.value = state.searchEngine;
    home.value = state.homepage;
    suggestions.checked = state.searchSuggestions;
    restore.checked = state.restoreSession;
    reduceMotion.checked = state.reduceMotion;
    customColor.value = state.accentColor;
    blurVal.textContent = `${state.blur}px`;
    opacityVal.textContent = `${state.opacity}%`;
    radiusVal.textContent = `${state.radius}px`;
    updateSwatchActive();

    blur.addEventListener("input", () => {
      state.blur = Number(blur.value);
      blurVal.textContent = `${state.blur}px`;
      apply(state);
      save(state);
    });
    opacity.addEventListener("input", () => {
      state.opacity = Number(opacity.value);
      opacityVal.textContent = `${state.opacity}%`;
      apply(state);
      save(state);
    });
    radius.addEventListener("input", () => {
      state.radius = Number(radius.value);
      radiusVal.textContent = `${state.radius}px`;
      apply(state);
      save(state);
    });
    search.addEventListener("change", () => {
      state.searchEngine = search.value;
      save(state);
    });
    home.addEventListener("change", () => {
      state.homepage = home.value.trim() || defaults.homepage;
      save(state);
    });
    suggestions.addEventListener("change", () => {
      state.searchSuggestions = suggestions.checked;
      save(state);
    });
    restore.addEventListener("change", () => {
      state.restoreSession = restore.checked;
      save(state);
      listeners.forEach((fn) => fn("restoreSession", state.restoreSession));
    });
    reduceMotion.addEventListener("change", () => {
      state.reduceMotion = reduceMotion.checked;
      apply(state);
      save(state);
    });
    clearData.addEventListener("click", () => {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem("geo:session");
      window.location.reload();
    });

    document.querySelectorAll("#opt-accent-swatches .swatch[data-color]").forEach((btn) => {
      btn.addEventListener("click", () => {
        state.accentColor = btn.dataset.color;
        customColor.value = state.accentColor;
        applyAccent(state.accentColor);
        updateThemeBadge();
        updateSwatchActive();
        save(state);
      });
    });
    customColor.addEventListener("input", () => {
      state.accentColor = customColor.value;
      applyAccent(state.accentColor);
      updateThemeBadge();
      updateSwatchActive();
      save(state);
    });

    const panel = document.getElementById("settings-panel");
    const overlay = document.getElementById("settings-overlay");
    const openBtn = document.getElementById("settings-btn");
    const closeBtn = document.getElementById("settings-close");

    // Exposed open/close so the shell can hide native webviews before showing
    // the panel, and restore them after it closes.
    function openPanel() { panel.classList.add("open"); overlay.classList.add("show"); }
    function closePanel() { panel.classList.remove("open"); overlay.classList.remove("show"); }

    // Wire up the close controls here (open is triggered by the shell to
    // ensure native views are withdrawn first).
    closeBtn.addEventListener("click", closePanel);
    overlay.addEventListener("click", closePanel);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closePanel();
    });

    // Theme-from-photo controls
    const photoInput = document.getElementById("opt-theme-photo");
    const photoApply = document.getElementById("opt-theme-photo-apply");
    const photoPreview = document.getElementById("opt-theme-photo-preview");
    let pendingHex = null;

    async function extractAverageColor(file) {
      try {
        const bitmap = await createImageBitmap(file);
        const w = 64;
        const h = Math.round((bitmap.height / bitmap.width) * w) || 64;
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(bitmap, 0, 0, w, h);
        const data = ctx.getImageData(0, 0, w, h).data;
        let r = 0, g = 0, b = 0, count = 0;
        for (let i = 0; i < data.length; i += 4) {
          r += data[i]; g += data[i + 1]; b += data[i + 2]; count++;
        }
        return [Math.round(r / count), Math.round(g / count), Math.round(b / count)];
      } catch (err) {
        return null;
      }
    }

    photoInput?.addEventListener("change", async (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const url = URL.createObjectURL(f);
      if (photoPreview) {
        photoPreview.innerHTML = `<img src="${url}" style="max-width:100%; max-height:80px; border-radius:8px; display:block;"/>`;
      }
      const rgb = await extractAverageColor(f);
      if (rgb) {
        pendingHex = rgbToHex(rgb);
        photoApply.disabled = false;
        photoApply.textContent = `Apply theme (${pendingHex})`;
      } else {
        pendingHex = null;
        photoApply.disabled = true;
        photoApply.textContent = `Apply theme from photo`;
      }
    });

    photoApply?.addEventListener("click", () => {
      if (!pendingHex) return;
      state.accentColor = pendingHex;
      document.getElementById("opt-accent-custom").value = state.accentColor;
      applyAccent(state.accentColor);
      updateThemeBadge();
      updateSwatchActive();
      save(state);
      pendingHex = null;
      photoApply.disabled = true;
      photoApply.textContent = `Apply theme from photo`;
    });

    // Populate exposed hooks
    openPanelFn = openPanel;
    closePanelFn = closePanel;
  }

  return {
    init,
    get: () => state,
    searchUrl: (query) => state.searchEngine + encodeURIComponent(query),
    homepage: () => state.homepage,
    onChange: (fn) => listeners.push(fn),
    openPanel: () => openPanelFn(),
    closePanel: () => closePanelFn(),
  };
})();
