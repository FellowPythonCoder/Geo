# Geo

Geo is a small desktop web browser you build and run on your own computer.
It has a frosted-glass look, tabs, a quick command menu (press ⌘K), and
colors you can customize.

## What makes Geo different

Most simple browser projects fake their tabs using something called an
`<iframe>`. The problem: big sites like Google **block** iframes on
purpose, as a security rule. So a fake browser like that shows an error
instead of the real page.

Geo doesn't do that. Every tab in Geo is a **real, separate browser
window** stacked on top of the app, the same way Chrome or Safari does
it. That means real websites load the normal way — nothing gets blocked.

Geo also has a fun trick: when a page from Google loads inside Geo, the
app automatically swaps the Google logo and the word "Google" for "Geo"
on the page. You'll see this happen live.

## What's inside this folder

```
Geo-Browser/
├── README.md          <- you are here
├── HOW-TO-RUN.txt      <- step-by-step instructions, no jargon
└── app/                <- the actual app code
    ├── package.json     tells npm how to start/build the app
    ├── src/              everything you SEE (the UI)
    │   ├── index.html    the page layout: sidebar, tabs, toolbar
    │   ├── css/           colors, spacing, the glass look
    │   │   ├── glass.css   the color/design rules
    │   │   └── app.css     everything else (layout, buttons, etc.)
    │   └── js/             the logic that makes buttons do things
    │       ├── app.js       tabs, navigation, the ⌘K menu
    │       └── settings.js  the settings screen
    └── src-tauri/         the part written in Rust that makes it a
                            real desktop app instead of just a webpage
        ├── src/main.rs      creates each tab as its own real window
        ├── Cargo.toml       Rust's version of package.json
        ├── build.rs         a small setup script Rust runs first
        └── tauri.conf.json  app name, window size, icon settings
```

## Before you run it

You need two free programs installed on your computer first:

1. **Node.js** — download it at https://nodejs.org (pick the LTS version)
2. **Rust** — install it at https://rustup.rs

You only need to do this once. After that, check
**HOW-TO-RUN.txt** for the exact steps to start the app.

## Good to know

- The first time you run it, your computer has to download and build a
  bunch of Rust code. That can take a few minutes — this is normal,
  it's not stuck.
- If it complains about a missing icon, that just means the app icon
  files haven't been created yet. HOW-TO-RUN.txt covers this too.
