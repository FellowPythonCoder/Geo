// app.js — tabs, workspaces, navigation, and the interaction animations
// (sliding tab indicator, drag-to-reorder, back/forward transitions,
// reload kick, window-drag wobble, search suggestions) for the Geo shell.

(function () {
  "use strict";

  let isTauri = typeof window.__TAURI__ !== "undefined";
  let brandInjectTimer = null;

  // ---------------------------------------------------------------------
  // Vault — saved logins, stored locally on-device (localStorage). This is
  // a convenience store, not a hardened secrets manager: entries are kept
  // in plain JSON on disk like the rest of Geo's local state, so treat it
  // the way you'd treat any local password autofill list.
  // ---------------------------------------------------------------------
  const Vault = (() => {
    const KEY = "geo:passwords";
    const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; } };
    const save = (list) => localStorage.setItem(KEY, JSON.stringify(list));
    return {
      list: () => load(),
      add: (site, username, password) => {
        const list = load();
        const idx = list.findIndex((e) => e.site === site && e.username === username);
        const entry = { site, username, password, updated: Date.now() };
        if (idx >= 0) list[idx] = entry; else list.unshift(entry);
        save(list);
        return list;
      },
      remove: (site, username) => {
        const list = load().filter((e) => !(e.site === site && e.username === username));
        save(list);
        return list;
      },
      clear: () => save([]),
    };
  })();

  // ---------------------------------------------------------------------
  // History — recently visited pages, most-recent first, capped at 500.
  // ---------------------------------------------------------------------
  const HistoryStore = (() => {
    const KEY = "geo:history";
    const CAP = 500;
    const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch { return []; } };
    const save = (list) => localStorage.setItem(KEY, JSON.stringify(list.slice(0, CAP)));
    return {
      list: () => load(),
      add: (url, title) => {
        if (!url || url === "about:start" || url.startsWith("geo://")) return;
        const list = load();
        list.unshift({ url, title: title || url, time: Date.now() });
        save(list);
      },
      remove: (time) => save(load().filter((e) => e.time !== time)),
      clear: () => save([]),
    };
  })();

  function logHistory(tab) {
    if (!tab || !tab.url || tab.url === "about:start") return;
    HistoryStore.add(tab.url, tab.display || tab.url);
  }

  // Tauri v2 may inject window.__TAURI__ after the page script runs if
  // `app.withGlobalTauri` isn't enabled at build-time. Poll briefly so that
  // the app can detect a late injection and enable native-webview code paths
  // instead of silently falling back to iframe-based preview.
  (function waitForTauriInjection() {
    if (isTauri) return;
    let checks = 0;
    const maxChecks = 100; // ~5s at 50ms intervals
    const id = setInterval(() => {
      if (typeof window.__TAURI__ !== "undefined") {
        isTauri = true;
        console.info("Tauri runtime detected (late injection). Enabling native paths.");
        clearInterval(id);
      } else if (++checks >= maxChecks) {
        clearInterval(id);
      }
    }, 50);
  })();

  function tauriInvoke(cmd, args) {
    const { invoke } = window.__TAURI__.core || window.__TAURI__.tauri;
    return invoke(cmd, args);
  }

  async function openInSystemBrowser(url) {
    if (isTauri) {
      try {
        await tauriInvoke("open_in_system_browser", { url });
        return;
      } catch (err) {
        console.warn("Tauri invoke failed, falling back to window.open", err);
      }
    }
    window.open(url, "_blank", "noopener,noreferrer");
  }

  // ---------- Native per-tab webviews (Tauri build only) ----------
  //
  // Real desktop builds no longer embed pages via <iframe> — an iframe
  // is subject to a site's own X-Frame-Options / CSP frame-ancestors
  // policy, and most real sites (search engines included) set one
  // specifically to refuse being framed. That's what made normal
  // searches and sites like google.com fail to load before.
  //
  // Instead each tab gets a real native child webview positioned over
  // the content area — a genuine top-level navigation done by the
  // OS's browser engine, exactly like a normal browser tab, so those
  // headers don't apply. Only one is ever shown at a time.
  //
  // Those native views always paint ON TOP of Geo's own HTML, so any
  // time Geo needs to show its own UI over the content area (command
  // palette, settings, the About panel, the focused address bar) the
  // active tab's view has to be explicitly hidden first, then shown
  // again after.

  let activeNativeTabId = null;
  // Pixels to inset the viewing area from the top so floating UI remains visible
  const VIEW_TOP_INSET = 40;

  function getViewBounds() {
    const r = document.getElementById("view-stack").getBoundingClientRect();
    const x = Math.round(r.left);
    const y = Math.round(r.top + VIEW_TOP_INSET);
    const width = Math.round(r.width);
    const height = Math.max(0, Math.round(r.height - VIEW_TOP_INSET));
    return { x, y, width, height };
  }

  function hideTabView(id) {
    if (!id) return;
    tauriInvoke("hide_tab_view", { id }).catch(() => {});
  }

  function withdrawActiveViewForOverlay() {
    if (isTauri) hideTabView(activeNativeTabId);
  }

  function restoreActiveViewFromOverlay() {
    if (isTauri && activeNativeTabId) {
      tauriInvoke("show_tab_view", { id: activeNativeTabId }).catch(() => {});
    }
  }

  async function showTabView(tab) {
    const b = getViewBounds();
    if (!tab.viewCreated) {
      tab.viewCreated = true;
      try {
        await tauriInvoke("create_tab_view", { id: tab.id, url: tab.url, ...b });
      } catch (err) {
        console.warn("create_tab_view failed", err);
      }
    } else {
      try {
        await tauriInvoke("set_tab_bounds", { id: tab.id, ...b });
        await tauriInvoke("show_tab_view", { id: tab.id });
      } catch (err) {
        console.warn("show_tab_view failed", err);
      }
    }
    activeNativeTabId = tab.id;
  }

  // ---------- Known-blocked hosts ----------
  // These sites' own CSP/X-Frame-Options headers refuse to render inside
  // ANY embedded browser view — not just Geo. Waiting on the iframe to
  // "fail" is unreliable for them (some just render a blank white page
  // forever instead of firing a detectable error), so we skip the
  // attempt entirely and go straight to the fallback UI.
  const KNOWN_BLOCKED_HOSTS = [
    /(^|\.)google\.[a-z.]+$/i,
    /(^|\.)accounts\.google\.com$/i,
    /(^|\.)facebook\.com$/i,
    /(^|\.)instagram\.com$/i,
    /(^|\.)twitter\.com$/i,
    /(^|\.)x\.com$/i,
    /(^|\.)linkedin\.com$/i,
    /(^|\.)netflix\.com$/i,
    /(^|\.)chase\.com$/i,
    /(^|\.)paypal\.com$/i,
  ];

  function isKnownBlocked(url) {
    try {
      const host = new URL(url).hostname;
      return KNOWN_BLOCKED_HOSTS.some((re) => re.test(host));
    } catch {
      return false;
    }
  }

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function normalizeInput(raw) {
    const value = raw.trim();
    if (!value) return null;
    if (value === "geo://start" || value === "glass://start") {
      return { url: "about:start", isStart: true };
    }

    const looksLikeUrl =
      /^[a-z][a-z0-9+.-]*:\/\//i.test(value) ||
      (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(value) && !value.includes(" "));

    if (looksLikeUrl) {
      const url = /^[a-z][a-z0-9+.-]*:\/\//i.test(value) ? value : `https://${value}`;
      return { url, isStart: false, isSearch: false, display: url };
    }
    // Not a URL — treat as a Geo search. The real request still goes to
    // the configured search backend, but the address bar and tab title
    // only ever show "Geo" + the query, never the backend's own domain.
    return { url: Settings.searchUrl(value), isStart: false, isSearch: true, display: value };
  }

  // ---------- State ----------

  let workspaces = [
    { id: "personal", name: "Personal", tabs: [], activeTabId: null },
    { id: "work", name: "Work", tabs: [], activeTabId: null },
  ];
  let activeWorkspaceId = workspaces[0].id;
  let tabSeq = 0;
  let frameBlockTimer = null;
  let draggedTabId = null;

  function activeWorkspace() {
    return workspaces.find((w) => w.id === activeWorkspaceId);
  }

  function makeTab(url, title) {
    tabSeq += 1;
    return {
      id: `t${tabSeq}`,
      url: url || "about:start",
      title: title || "New Tab",
      isSearch: false,
      display: url || "about:start",
      viewCreated: false,
    };
  }

  // ---------- Session persistence (opt-in via Settings) ----------

  let saveSessionTimer = null;
  function saveSession() {
    if (!Settings.get().restoreSession) return;
    clearTimeout(saveSessionTimer);
    saveSessionTimer = setTimeout(() => {
      try {
        localStorage.setItem(
          "geo:session",
          JSON.stringify({ workspaces, activeWorkspaceId })
        );
      } catch {
        /* storage full or unavailable — not fatal */
      }
    }, 300);
  }

  function loadSession() {
    if (!Settings.get().restoreSession) return false;
    try {
      const raw = localStorage.getItem("geo:session");
      if (!raw) return false;
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.workspaces)) return false;
      workspaces = parsed.workspaces.map((w) => ({ ...w, tabs: w.tabs || [] }));
      activeWorkspaceId = parsed.activeWorkspaceId || workspaces[0]?.id;
      tabSeq = workspaces.reduce((max, w) => {
        w.tabs.forEach((t) => {
          const n = Number(String(t.id).replace("t", ""));
          if (!Number.isNaN(n)) max = Math.max(max, n);
        });
        return max;
      }, 0);
      return workspaces.some((w) => w.tabs.length > 0);
    } catch {
      return false;
    }
  }

  // ---------- Tabs ----------

  function createTab(url) {
    const ws = activeWorkspace();
    const tab = makeTab(url);
    ws.tabs.push(tab);
    renderTabs();
    activateTab(tab.id);
  }

  function closeTab(id) {
    const ws = activeWorkspace();
    const idx = ws.tabs.findIndex((t) => t.id === id);
    if (idx === -1) return;
    const wasActive = ws.tabs[idx].id === ws.activeTabId;
    if (isTauri) {
      if (ws.tabs[idx].viewCreated) tauriInvoke("close_tab_view", { id }).catch(() => {});
      if (activeNativeTabId === id) activeNativeTabId = null;
    } else {
      document.getElementById(`frame-${id}`)?.remove();
    }
    ws.tabs.splice(idx, 1);
    if (wasActive) {
      const next = ws.tabs[idx] || ws.tabs[idx - 1];
      ws.activeTabId = next ? next.id : null;
    }
    renderTabs();
    renderActiveView();
    saveSession();
  }

  function activateTab(id) {
    activeWorkspace().activeTabId = id;
    renderTabs();
    renderActiveView();
    saveSession();
  }

  function currentTab() {
    const ws = activeWorkspace();
    return ws.tabs.find((t) => t.id === ws.activeTabId) || null;
  }

  // ---------- Sliding tab indicator ----------

  function updateTabIndicator() {
    const indicator = document.getElementById("tab-indicator");
    const list = document.getElementById("tab-list");
    const activeEl = list.querySelector(".tab-item.active");
    if (!activeEl) {
      indicator.classList.remove("show");
      return;
    }
    const listRect = list.getBoundingClientRect();
    const rect = activeEl.getBoundingClientRect();
    indicator.style.transform = `translateY(${rect.top - listRect.top}px)`;
    indicator.style.height = `${rect.height}px`;
    indicator.classList.add("show");
  }

  // ---------- Drag-to-reorder tabs (with FLIP animation) ----------

  function reorderTab(draggedId, targetId, before) {
    const ws = activeWorkspace();
    const from = ws.tabs.findIndex((t) => t.id === draggedId);
    if (from === -1) return;
    const [moved] = ws.tabs.splice(from, 1);
    let to = ws.tabs.findIndex((t) => t.id === targetId);
    if (to === -1) to = ws.tabs.length;
    ws.tabs.splice(before ? to : to + 1, 0, moved);
    renderTabsAnimated();
    saveSession();
  }

  function renderTabsAnimated() {
    const list = document.getElementById("tab-list");
    const items = [...list.querySelectorAll(".tab-item")];
    const firstRects = new Map(items.map((el) => [el.dataset.id, el.getBoundingClientRect()]));

    renderTabs();

    const newItems = [...list.querySelectorAll(".tab-item")];
    newItems.forEach((el) => {
      const first = firstRects.get(el.dataset.id);
      if (!first) return;
      const last = el.getBoundingClientRect();
      const dy = first.top - last.top;
      if (dy) {
        el.style.transition = "none";
        el.style.transform = `translateY(${dy}px)`;
        requestAnimationFrame(() => {
          el.style.transition = `transform var(--dur-med) var(--ease-spring)`;
          el.style.transform = "";
        });
      }
    });
  }

  function renderTabs() {
    const list = document.getElementById("tab-list");
    const ws = activeWorkspace();
    // Keep the indicator element — only replace the tab items themselves.
    list.querySelectorAll(".tab-item").forEach((el) => el.remove());

    ws.tabs.forEach((tab) => {
      const el = document.createElement("div");
      el.className = "tab-item" + (tab.id === ws.activeTabId ? " active" : "");
      el.dataset.id = tab.id;
      el.draggable = true;
      const icon = tab.isStart ? "✦" : tab.isSearch ? "⌕" : "◌";
      el.innerHTML = `
        <span class="tab-favicon">${icon}</span>
        <span class="tab-title">${escapeHtml(tab.title || tab.display || tab.url)}</span>
        <span class="tab-close" title="Close tab">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </span>`;

      el.addEventListener("click", (e) => {
        if (e.target.closest(".tab-close")) {
          closeTab(tab.id);
        } else {
          activateTab(tab.id);
        }
      });

      el.addEventListener("dragstart", (e) => {
        draggedTabId = tab.id;
        el.classList.add("dragging");
        e.dataTransfer.effectAllowed = "move";
        try { e.dataTransfer.setData("text/plain", tab.id); } catch {}
      });
      el.addEventListener("dragend", () => {
        el.classList.remove("dragging");
        list.querySelectorAll(".tab-item").forEach((n) => n.classList.remove("drag-target-before", "drag-target-after"));
        draggedTabId = null;
      });
      el.addEventListener("dragover", (e) => {
        if (!draggedTabId || draggedTabId === tab.id) return;
        e.preventDefault();
        const rect = el.getBoundingClientRect();
        const before = e.clientY - rect.top < rect.height / 2;
        el.classList.toggle("drag-target-before", before);
        el.classList.toggle("drag-target-after", !before);
      });
      el.addEventListener("dragleave", () => {
        el.classList.remove("drag-target-before", "drag-target-after");
      });
      el.addEventListener("drop", (e) => {
        e.preventDefault();
        if (!draggedTabId || draggedTabId === tab.id) return;
        const rect = el.getBoundingClientRect();
        const before = e.clientY - rect.top < rect.height / 2;
        reorderTab(draggedTabId, tab.id, before);
      });

      list.appendChild(el);
    });

    updateTabIndicator();
  }

  function updateNavButtonsState(tab) {
    const onPage = !!tab && tab.url !== "about:start";
    ["back-btn", "fwd-btn", "reload-btn", "open-system-btn"].forEach((id) => {
      document.getElementById(id).disabled = !onPage;
    });
  }

  function renderActiveView() {
    const searchBar = document.getElementById("search-brand-bar");
    const tab = currentTab();
    searchBar.classList.remove("show");
    updateNavButtonsState(tab);

    if (isTauri) {
      renderActiveViewTauri(tab, searchBar);
    } else {
      renderActiveViewIframe(tab, searchBar);
    }
  }

  // Real desktop build: position/show the current tab's native webview,
  // hiding whichever one was showing before.
  function buildGeoBrandingScript(accent) {
    return [
      "(() => {",
      "  try {",
      "    if (!document || !document.location || !document.location.href) return;",
      "    if (String(document.location.href) === 'about:blank') return;",
      "    const rgba = (hex, alpha) => {",
      "      const clean = String(hex || '#3d8bff').replace('#', '');",
      "      const full = clean.length === 3 ? clean.split('').map((ch) => ch + ch).join('') : clean;",
      "      const value = Number.parseInt(full, 16) || 0x3d8bff;",
      "      const r = (value >> 16) & 255;",
      "      const g = (value >> 8) & 255;",
      "      const b = value & 255;",
      "      return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';",
      "    };",
      "    const svg = '<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 160 42\"><text x=\"4\" y=\"29\" font-family=\"Arial, Helvetica, sans-serif\" font-weight=\"700\" font-size=\"28\" fill=\"' + accent + '\">Geo</text></svg>';",
      "    const logoUrl = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);",
      "    const style = document.createElement('style');",
      "    style.id = 'geo-brand-style';",
      "    style.textContent = 'html, body { background: ' + rgba(accent, 0.94) + ' !important; background-color: ' + rgba(accent, 0.94) + ' !important; } body, main, #main, #rcnt, #rso, #search, .MjjYud, .RNNXgb, .gLFyf, .A8mHGb, .aajZCb, .gb_7f, .gb_6b, .N54Nn, .HDBW6d, .sfbg, .minidiv, .card-section, .g, .kp-wholepage, .liYKde, .xpdopen { background: ' + rgba(accent, 0.9) + ' !important; background-color: ' + rgba(accent, 0.9) + ' !important; } input, textarea, .gLFyf, .RNNXgb { background: rgba(255,255,255,0.92) !important; } a, a:visited, a:link { color: ' + accent + ' !important; } a:hover { color: ' + accent + 'cc !important; } h1, h2, h3, .LC20lb, .DKV0Md { color: #0b1220 !important; } button, input[type=\"submit\"], [role=\"button\"], .gNO89b, .RNNXgb { background: rgba(255,255,255,0.85) !important; border-color: ' + accent + ' !important; color: #0f172a !important; } ::selection { background: ' + accent + ' !important; color: #fff !important; } * { box-shadow: none !important; scrollbar-color: ' + accent + ' transparent !important; }';",
      "    const oldStyle = document.getElementById('geo-brand-style');",
      "    if (oldStyle) oldStyle.remove();",
      "    document.head && document.head.appendChild(style);",
      "    const overlay = document.createElement('div');",
      "    overlay.id = 'geo-tint-overlay';",
      "    overlay.style.position = 'fixed';",
      "    overlay.style.inset = '0';",
      "    overlay.style.zIndex = '2147483647';",
      "    overlay.style.pointerEvents = 'none';",
      "    overlay.style.opacity = '0.55';",
      "    overlay.style.mixBlendMode = 'multiply';",
      "    overlay.style.background = 'radial-gradient(circle at top left, ' + rgba(accent, 0.35) + ', transparent 55%), linear-gradient(180deg, ' + rgba(accent, 0.28) + ', ' + rgba(accent, 0.12) + ')';",
      "    const oldOverlay = document.getElementById('geo-tint-overlay');",
      "    if (oldOverlay) oldOverlay.remove();",
      "    document.documentElement.appendChild(overlay);",
      "    const bar = document.createElement('div');",
      "    bar.id = 'geo-inject-brandbar';",
      "    bar.style.cssText = 'position:fixed;top:0;left:0;right:0;height:46px;z-index:2147483647;display:flex;align-items:center;gap:10px;padding:0 16px;background:' + accent + ';color:#fff;font:700 16px -apple-system,Segoe UI,Roboto,sans-serif;pointer-events:none;';",
      "    bar.innerHTML = '<img src=\"' + logoUrl.replace(accent, '%23ffffff') + '\" style=\"height:22px;filter:brightness(0) invert(1);\"><span>Geo</span>';",
      "    const oldBar = document.getElementById('geo-inject-brandbar');",
      "    if (oldBar) oldBar.remove();",
      "    document.documentElement.appendChild(bar);",
      "    if (document.body) document.body.style.marginTop = '46px';",
      "    const replace = () => {",
      "      const selectors = ['img[alt*=\'Google\']', 'img[alt=\'Google\']', 'img[alt=\'Google Search\']', '#hplogo', '.lnXdpd', '.google-logo', '.logo', '[aria-label*=\'Google\']', 'img[src*=\'google\']'];",
      "      selectors.forEach((selector) => {",
      "        document.querySelectorAll(selector).forEach((el) => {",
      "          try {",
      "            if (el.tagName === 'IMG') {",
      "              el.src = logoUrl;",
      "              el.alt = 'Geo';",
      "            } else {",
      "              el.innerHTML = '<img src=\"' + logoUrl + '\" alt=\"Geo\" style=\"height:40px;display:block;max-height:40px;\">';",
      "            }",
      "          } catch (e) {}",
      "        });",
      "      });",
      "      ['hplogo', 'logo', 'lga'].forEach((id) => {",
      "        const el = document.getElementById(id);",
      "        if (!el) return;",
      "        try {",
      "          if (el.tagName === 'IMG') {",
      "            el.src = logoUrl;",
      "            el.alt = 'Geo';",
      "          } else {",
      "            el.innerHTML = '<img src=\"' + logoUrl + '\" alt=\"Geo\" style=\"height:40px;display:block;max-height:40px;\">';",
      "          }",
      "        } catch (e) {}",
      "      });",
      "      const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, null);",
      "      while (walker.nextNode()) {",
      "        const node = walker.currentNode;",
      "        if (node && node.nodeType === 3 && /Google/gi.test(node.nodeValue)) {",
      "          node.nodeValue = node.nodeValue.replace(/Google/gi, 'Geo');",
      "        }",
      "      }",
      "    };",
      "    replace();",
      "    try {",
      "      const observer = new MutationObserver(() => replace());",
      "      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'alt', 'class', 'style'] });",
      "    } catch (e) {}",
      "  } catch (e) {}",
      "})();",
    ].join('');
  }

  function renderActiveViewTauri(tab, searchBar) {
    const startPage = document.getElementById("start-page");

    if (activeNativeTabId && (!tab || activeNativeTabId !== tab.id)) {
      hideTabView(activeNativeTabId);
      activeNativeTabId = null;
    }

    if (!tab || tab.url === "about:start") {
      startPage.classList.add("active");
      document.getElementById("addr-input").value = "";
      if (brandInjectTimer) { clearInterval(brandInjectTimer); brandInjectTimer = null; }
      return;
    }
    startPage.classList.remove("active");
    document.getElementById("addr-input").value = tab.isSearch ? `Geo — ${tab.display}` : tab.display;
    if (tab.isSearch) {
      document.getElementById("search-brand-query").textContent = tab.display;
      searchBar.classList.add("show");
    }
    showTabView(tab);
    if (brandInjectTimer) { clearInterval(brandInjectTimer); brandInjectTimer = null; }
    const injectBrand = () => {
      try {
        const accent = (Settings && Settings.get && Settings.get().accentColor) || '#3d8bff';
        const script = buildGeoBrandingScript(accent);
        tauriInvoke('tab_eval', { id: tab.id, script }).catch(() => {});
      } catch (e) {}
    };
    // Fire once shortly after navigation, then keep re-applying — Google's
    // results/search pages are single-page apps that re-render their own
    // DOM (new searches, image tab, infinite scroll) without a fresh page
    // load, so a one-shot injection gets overwritten within a second or two.
    setTimeout(injectBrand, 220);
    brandInjectTimer = setInterval(injectBrand, 1200);
    logHistory(tab);
  }

  // Browser-preview build (no Tauri backend available): the original
  // <iframe> embed. Real sites with framing protections will still
  // refuse to load here — that's only fixable inside the actual
  // desktop app, which uses real native webviews instead (see above).
  function renderActiveViewIframe(tab, searchBar) {
    const stack = document.getElementById("view-stack");
    const startPage = document.getElementById("start-page");
    const blocked = document.getElementById("frame-blocked");
    const loading = document.getElementById("frame-loading");

    stack.querySelectorAll(".view-frame").forEach((f) => f.classList.remove("active"));
    blocked.classList.remove("show");
    loading.classList.remove("show");
    clearTimeout(frameBlockTimer);

    if (!tab || tab.url === "about:start") {
      startPage.classList.add("active");
      document.getElementById("addr-input").value = "";
      return;
    }
    startPage.classList.remove("active");
    // Never show the search backend's own URL — the address bar reflects
    // either the real site URL, or "Geo — <query>" for search results.
    document.getElementById("addr-input").value = tab.isSearch ? `Geo — ${tab.display}` : tab.display;

    // Geo-branded strip pinned above results for search tabs, so a
    // search always reads as "Geo" first rather than the backend's
    // own logo/chrome underneath it.
    if (tab.isSearch) {
      document.getElementById("search-brand-query").textContent = tab.display;
      searchBar.classList.add("show");
    }

    let frame = document.getElementById(`frame-${tab.id}`);
    if (!frame && isKnownBlocked(tab.url)) {
      // Don't even attempt the embed for sites known to refuse it —
      // avoids the "stuck on white" wait entirely.
      showBlocked(tab);
      return;
    }
    if (!frame) {
      frame = document.createElement("iframe");
      frame.id = `frame-${tab.id}`;
      frame.className = "view-frame";
      frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation-by-user-activation");
      frame.referrerPolicy = "no-referrer-when-downgrade";
      if (tab.isSearch) frame.classList.add("has-search-bar");
      // Lower iframe by VIEW_TOP_INSET so it doesn't overlap floating UI
      frame.style.top = `${VIEW_TOP_INSET}px`;
      frame.style.height = `calc(100% - ${VIEW_TOP_INSET}px)`;
      stack.insertBefore(frame, blocked);

      let settled = false;
      loading.classList.add("show");
      frame.addEventListener("load", () => {
        settled = true;
        loading.classList.remove("show");
        document.getElementById("reload-btn").classList.remove("loading");
        // Sites that refuse to be framed (X-Frame-Options / CSP
        // frame-ancestors) still fire `load` — the navigation gets
        // aborted and the frame is left on about:blank rather than
        // erroring. That's same-origin to us, so we CAN read its
        // location (a real cross-origin success would throw here).
        try {
          const href = frame.contentWindow && frame.contentWindow.location.href;
          if (href === "about:blank") {
            showBlocked(tab);
            return;
          }
        } catch {
          // Threw = cross-origin = the real site actually loaded. Fine.
        }

        // Try to inject branding into same-origin iframes (best-effort).
        try {
          const accent = (Settings && Settings.get && Settings.get().accentColor) || '#3d8bff';
          const doc = frame.contentDocument || frame.contentWindow.document;
          if (doc) {
            const rgba = (hex, alpha) => {
              const clean = String(hex || '#3d8bff').replace('#', '');
              const full = clean.length === 3 ? clean.split('').map((ch) => ch + ch).join('') : clean;
              const value = Number.parseInt(full, 16) || 0x3d8bff;
              const r = (value >> 16) & 255;
              const g = (value >> 8) & 255;
              const b = value & 255;
              return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
            };
            const style = doc.createElement('style');
            style.id = 'geo-brand-style';
            style.textContent = `html, body { background: ${rgba(accent, 0.09)} !important; background-color: ${rgba(accent, 0.09)} !important; } body, main, #main { background: ${rgba(accent, 0.12)} !important; } a { color: ${accent} !important; }`;
            const oldStyle = doc.getElementById('geo-brand-style');
            if (oldStyle) oldStyle.remove();
            doc.head && doc.head.appendChild(style);

            const overlay = doc.createElement('div');
            overlay.id = 'geo-tint-overlay';
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.pointerEvents = 'none';
            overlay.style.zIndex = '2147483646';
            overlay.style.opacity = '0.8';
            overlay.style.background = `radial-gradient(circle at top left, ${rgba(accent, 0.18)}, transparent 45%), linear-gradient(180deg, ${rgba(accent, 0.12)}, ${rgba(accent, 0.04)})`;
            const oldOverlay = doc.getElementById('geo-tint-overlay');
            if (oldOverlay) oldOverlay.remove();
            doc.documentElement.appendChild(overlay);

            const logoUrl = (() => {
              const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 42"><text x="4" y="29" font-family="Arial, Helvetica, sans-serif" font-weight="700" font-size="28" fill="${accent}">Geo</text></svg>`;
              return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
            })();
            const replaceLogo = () => {
              doc.querySelectorAll('img[alt*="Google"], img[alt="Google"], img[alt="Google Search"], #hplogo, .lnXdpd, .google-logo, .logo, [aria-label*="Google"], img[src*="google"]').forEach((img) => {
                try {
                  img.src = logoUrl;
                  img.alt = 'Geo';
                } catch (e) {}
              });
              ['hplogo', 'logo', 'lga'].forEach((id) => {
                const el = doc.getElementById(id);
                if (!el) return;
                try {
                  if (el.tagName === 'IMG') {
                    el.src = logoUrl;
                    el.alt = 'Geo';
                  } else {
                    el.innerHTML = '<img src="' + logoUrl + '" alt="Geo" style="height:40px;display:block;max-height:40px;">';
                  }
                } catch (e) {}
              });
              const walker = doc.createTreeWalker(doc.body || doc.documentElement, 4, null);
              while (walker.nextNode()) {
                const node = walker.currentNode;
                if (node && node.nodeType === 3 && /Google/gi.test(node.nodeValue)) {
                  node.nodeValue = node.nodeValue.replace(/Google/gi, 'Geo');
                }
              }
            };
            replaceLogo();
          }
        } catch (e) {
          // cross-origin or DOM access blocked — ignore
        }
      });
      frame.addEventListener("error", () => showBlocked(tab));
      try {
        setTimeout(() => {
          try {
            const doc = frame.contentDocument || frame.contentWindow.document;
            if (!doc) return;
            const accent = (Settings && Settings.get && Settings.get().accentColor) || '#3d8bff';
            const rgba = (hex, alpha) => {
              const clean = String(hex || '#3d8bff').replace('#', '');
              const full = clean.length === 3 ? clean.split('').map((ch) => ch + ch).join('') : clean;
              const value = Number.parseInt(full, 16) || 0x3d8bff;
              const r = (value >> 16) & 255;
              const g = (value >> 8) & 255;
              const b = value & 255;
              return 'rgba(' + r + ', ' + g + ', ' + b + ', ' + alpha + ')';
            };
            const light = rgba(accent, 0.06);
            doc.documentElement.style.backgroundColor = light;
            if (doc.body) doc.body.style.backgroundColor = light;
            const url = (() => {
              const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 42"><text x="4" y="29" font-family="Arial, Helvetica, sans-serif" font-weight="700" font-size="28" fill="${accent}">Geo</text></svg>`;
              return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
            })();
            ['hplogo', 'logo', 'lga'].forEach((id) => {
              try {
                const el = doc.getElementById(id);
                if (!el) return;
                if (el.tagName === 'IMG') {
                  el.src = url;
                  el.alt = 'Geo';
                } else {
                  el.innerHTML = '<img src="' + url + '" alt="Geo" style="height:40px;display:block;max-height:40px;">';
                }
              } catch (e) {}
            });
            doc.querySelectorAll('img[alt*="Google"]').forEach((img) => {
              try {
                img.src = url;
                img.alt = 'Geo';
              } catch (e) {}
            });
          } catch (e) {}
        }, 180);
      } catch (e) {}
      frame.src = tab.url;

      // 3.5s is plenty for a same-machine embed attempt to either
      // start painting or get silently aborted by the site's framing
      // policy — waiting longer just leaves a blank pane on screen.
      frameBlockTimer = setTimeout(() => {
        if (!settled && frame.classList.contains("active")) showBlocked(tab);
      }, 3500);    } else if (!document.getElementById("reload-btn").classList.contains("loading")) {
      loading.classList.remove("show");
    }
    frame.classList.add("active");
  }

  function showBlocked(tab) {
    document.getElementById("frame-loading").classList.remove("show");
    document.getElementById("search-brand-bar").classList.remove("show");
    document.getElementById("frame-blocked").classList.add("show");
    document.getElementById("frame-blocked-open").onclick = () => openInSystemBrowser(tab.url);
  }

  function navigate(rawInput) {
    const parsed = normalizeInput(rawInput);
    if (!parsed) return;
    let tab = currentTab();
    if (!tab) {
      createTab(parsed.isStart ? null : parsed.url);
      return;
    }
    tab.url = parsed.isStart ? "about:start" : parsed.url;
    tab.isSearch = !!parsed.isSearch;
    tab.display = parsed.isStart ? "about:start" : parsed.display;
    tab.title = parsed.isStart
      ? "New Tab"
      : parsed.isSearch
        ? parsed.display
        : parsed.url.replace(/^https?:\/\//, "");
    if (isTauri) {
      if (tab.viewCreated && tab.url !== "about:start") {
        tauriInvoke("navigate_tab_view", { id: tab.id, url: tab.url }).catch(() => {});
      } else if (tab.url === "about:start" && tab.viewCreated) {
        // Going back to the start page — drop the native view entirely
        // rather than leaving a stale page loaded behind it.
        tauriInvoke("close_tab_view", { id: tab.id }).catch(() => {});
        tab.viewCreated = false;
        if (activeNativeTabId === tab.id) activeNativeTabId = null;
      }
    } else {
      document.getElementById(`frame-${tab.id}`)?.remove();
    }
    renderTabs();
    renderActiveView();
    saveSession();
  }

  // ---------- Search suggestions ----------

  function wireSuggestions(inputEl, dropdownEl, formEl) {
    let debounceTimer = null;
    let items = [];
    let highlighted = -1;

    function hide() {
      dropdownEl.classList.remove("show");
      dropdownEl.innerHTML = "";
      items = [];
      highlighted = -1;
    }

    function select(text) {
      inputEl.value = text;
      hide();
      navigate(text);
    }

    function render() {
      dropdownEl.innerHTML = items
        .map(
          (s, i) => `
        <button type="button" class="suggest-item${i === highlighted ? " highlighted" : ""}" data-i="${i}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          ${escapeHtml(s)}
        </button>`
        )
        .join("");
      dropdownEl.querySelectorAll(".suggest-item").forEach((btn) => {
        btn.addEventListener("mousedown", (e) => {
          e.preventDefault();
          select(items[Number(btn.dataset.i)]);
        });
      });
      dropdownEl.classList.toggle("show", items.length > 0);
    }

    async function fetchSuggestions(q) {
      try {
        const res = await fetch(`https://duckduckgo.com/ac/?q=${encodeURIComponent(q)}&type=list`);
        if (!res.ok) throw new Error("bad response");
        const data = await res.json();
        items = Array.isArray(data) ? data.map((d) => d.phrase).filter(Boolean).slice(0, 6) : [];
        highlighted = -1;
        render();
      } catch {
        // Network unavailable, endpoint blocked, or offline — fail silent,
        // the address bar still works fine without suggestions.
        hide();
      }
    }

    inputEl.addEventListener("input", () => {
      clearTimeout(debounceTimer);
      const q = inputEl.value.trim();
      const isUrlLike = /^[a-z][a-z0-9+.-]*:\/\//i.test(q) || q === "geo://start";
      if (!Settings.get().searchSuggestions || !q || isUrlLike) {
        hide();
        return;
      }
      debounceTimer = setTimeout(() => fetchSuggestions(q), 180);
    });

    inputEl.addEventListener("keydown", (e) => {
      if (!items.length) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        highlighted = (highlighted + 1) % items.length;
        render();
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        highlighted = (highlighted - 1 + items.length) % items.length;
        render();
      } else if (e.key === "Enter" && highlighted >= 0) {
        e.preventDefault();
        select(items[highlighted]);
      } else if (e.key === "Escape") {
        hide();
      }
    });

    inputEl.addEventListener("blur", () => setTimeout(hide, 120));
    formEl?.addEventListener("submit", hide);
  }

  // ---------- Workspaces ----------

  function renderWorkspaces() {
    const wrap = document.getElementById("workspace-pills");
    wrap.innerHTML = workspaces
      .map(
        (w) => `
      <button class="ws-pill${w.id === activeWorkspaceId ? " active" : ""}" data-id="${w.id}">
        <span class="ws-dot"></span>${escapeHtml(w.name)}
      </button>`
      )
      .join("");
    wrap.querySelectorAll(".ws-pill").forEach((btn) => {
      btn.addEventListener("click", () => {
        activeWorkspaceId = btn.dataset.id;
        renderWorkspaces();
        renderTabs();
        renderActiveView();
      });
    });
  }

  // ---------- Command palette ----------

  function getCommands() {
    const ws = activeWorkspace();
    const cmds = [
      { label: "New Tab", hint: "⌘T", icon: "plus", run: () => createTab(null) },
      { label: "Close Tab", hint: "⌘W", icon: "close", run: () => { const t = currentTab(); if (t) closeTab(t.id); } },
      { label: "Reload Page", hint: "", icon: "reload", run: () => document.getElementById("reload-btn").click() },
      { label: "Go Back", hint: "", icon: "back", run: () => document.getElementById("back-btn").click() },
      { label: "Go Forward", hint: "", icon: "fwd", run: () => document.getElementById("fwd-btn").click() },
      { label: "Focus Address Bar", hint: "⌘L", icon: "search", run: () => { document.getElementById("addr-input").focus(); document.getElementById("addr-input").select(); } },
      { label: "Toggle Sidebar", hint: "", icon: "sidebar", run: () => document.getElementById("shell").classList.toggle("collapsed") },
      { label: "Open Settings", hint: "", icon: "settings", run: () => document.getElementById("settings-btn").click() },
      { label: "Open in System Browser", hint: "", icon: "external", run: () => { const t = currentTab(); if (t && t.url !== "about:start") openInSystemBrowser(t.url); } },
      { label: "About Geo", hint: "", icon: "earth", run: () => openAbout() },
    ];
    workspaces.forEach((w) => {
      if (w.id === activeWorkspaceId) return;
      cmds.push({
        label: `Switch to ${w.name}`,
        hint: "",
        icon: "workspace",
        run: () => { activeWorkspaceId = w.id; renderWorkspaces(); renderTabs(); renderActiveView(); },
      });
    });
    ws.tabs.forEach((t) => {
      if (t.id === ws.activeTabId) return;
      cmds.push({
        label: `Go to tab: ${t.title || t.display || t.url}`,
        hint: "",
        icon: "tab",
        run: () => activateTab(t.id),
      });
    });
    return cmds;
  }

  const CMDK_ICONS = {
    plus: '<path d="M12 5v14M5 12h14"/>',
    close: '<path d="M18 6L6 18M6 6l12 12"/>',
    reload: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>',
    back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    fwd: '<path d="M5 12h14M12 5l7 7-7 7"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>',
    sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82"/>',
    external: '<path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><path d="M15 3h6v6M10 14L21 3"/>',
    earth: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.5 3.8 5.6 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.6-3.8-9S9.5 5.5 12 3z"/>',
    workspace: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    tab: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18"/>',
  };

  let cmdkHighlighted = 0;
  let cmdkFiltered = [];

  function renderCmdk(query) {
    const all = getCommands();
    const q = query.trim().toLowerCase();
    cmdkFiltered = q ? all.filter((c) => c.label.toLowerCase().includes(q)) : all;
    cmdkHighlighted = 0;

    const list = document.getElementById("cmdk-list");
    if (!cmdkFiltered.length) {
      list.innerHTML = `<div class="cmdk-empty">No matching commands</div>`;
      return;
    }
    list.innerHTML = cmdkFiltered
      .map(
        (c, i) => `
      <div class="cmdk-item${i === cmdkHighlighted ? " highlighted" : ""}" data-i="${i}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">${CMDK_ICONS[c.icon] || ""}</svg>
        <span class="cmdk-label">${escapeHtml(c.label)}</span>
        ${c.hint ? `<kbd class="cmdk-hint">${c.hint}</kbd>` : ""}
      </div>`
      )
      .join("");
    list.querySelectorAll(".cmdk-item").forEach((el) => {
      el.addEventListener("click", () => runCmdk(Number(el.dataset.i)));
      el.addEventListener("mouseenter", () => {
        cmdkHighlighted = Number(el.dataset.i);
        list.querySelectorAll(".cmdk-item").forEach((n) => n.classList.remove("highlighted"));
        el.classList.add("highlighted");
      });
    });
  }

  function runCmdk(i) {
    const cmd = cmdkFiltered[i];
    closeCmdk();
    if (cmd) cmd.run();
  }

  function openCmdk() {
    withdrawActiveViewForOverlay();
    const overlay = document.getElementById("cmdk-overlay");
    const panel = document.getElementById("cmdk-panel");
    const input = document.getElementById("cmdk-input");
    overlay.classList.add("show");
    panel.classList.add("show");
    input.value = "";
    renderCmdk("");
    setTimeout(() => input.focus(), 10);
  }

  function closeCmdk() {
    document.getElementById("cmdk-overlay").classList.remove("show");
    document.getElementById("cmdk-panel").classList.remove("show");
    restoreActiveViewFromOverlay();
  }

  function wireCmdk() {
    document.getElementById("cmdk-btn").addEventListener("click", openCmdk);
    document.getElementById("cmdk-overlay").addEventListener("click", closeCmdk);
    document.getElementById("cmdk-input").addEventListener("input", (e) => renderCmdk(e.target.value));
    document.getElementById("cmdk-form").addEventListener("submit", (e) => {
      e.preventDefault();
      runCmdk(cmdkHighlighted);
    });
    document.getElementById("cmdk-input").addEventListener("keydown", (e) => {
      if (e.key === "Escape") { closeCmdk(); return; }
      if (!cmdkFiltered.length) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        cmdkHighlighted = (cmdkHighlighted + 1) % cmdkFiltered.length;
        renderCmdk(document.getElementById("cmdk-input").value);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        cmdkHighlighted = (cmdkHighlighted - 1 + cmdkFiltered.length) % cmdkFiltered.length;
        renderCmdk(document.getElementById("cmdk-input").value);
      }
    });
  }

  // ---------- About / Geofetch panel ----------

  function openAbout() {
    const ws = activeWorkspace();
    const totalTabs = workspaces.reduce((n, w) => n + w.tabs.length, 0);
    const accent = Settings.get().accentColor;

    document.getElementById("about-body").innerHTML = `
      <div class="fetch-row">
        <svg class="fetch-logo earth-cartoon" viewBox="0 0 48 48">
          <defs>
            <radialGradient id="earthOceanAbout" cx="35%" cy="28%" r="75%">
              <stop offset="0%" stop-color="#8fd6ff"/>
              <stop offset="55%" stop-color="#2f8fe0"/>
              <stop offset="100%" stop-color="#1c5fa8"/>
            </radialGradient>
          </defs>
          <circle cx="24" cy="24" r="20.5" fill="url(#earthOceanAbout)" stroke="var(--accent-strong)" stroke-width="1.5"/>
          <g fill="var(--accent)">
            <path d="M30 9c4-.6 7.7 2 7.3 5.7 3 1.6 2.7 6.2-1 5.9 1 3.8-2.8 6.4-6 4.4-3.4 2.2-7.3-.7-6-4.4-2.7-1.4-2.2-5.6 1-6.2-.6-2.3.8-4.7 3-4.8.2-1 .8-1.3 1.7-.6z"/>
            <path d="M15 27c2.8-.7 5.6 1.2 5 4-.2 3.4-4.2 4.8-6.6 2.6-2.6 2-6.2-.3-5.4-3.4-2.3-1-2-4.4.5-5 .1-1.6 1.6-2.7 3.1-2 .5-1 1.6-1.2 2.4-.4z"/>
          </g>
        </svg>
        <div class="fetch-info">
          <div class="fetch-title">geo@browser</div>
          <div class="fetch-sub">Blue-green Liquid Glass, rebuilt for speed</div>
          <div class="fetch-line"><span class="fetch-key">Theme</span><span class="fetch-val">${escapeHtml(document.getElementById("theme-badge")?.textContent || "Earth Glass")}</span></div>
          <div class="fetch-line"><span class="fetch-key">Accent</span><span class="fetch-val">${escapeHtml(accent)}</span></div>
          <div class="fetch-line"><span class="fetch-key">Workspace</span><span class="fetch-val">${escapeHtml(ws.name)} (${ws.tabs.length} tab${ws.tabs.length === 1 ? "" : "s"})</span></div>
          <div class="fetch-line"><span class="fetch-key">Total tabs</span><span class="fetch-val">${totalTabs}</span></div>
          <div class="fetch-line"><span class="fetch-key">Shortcuts</span><span class="fetch-val">⌘K ⌘T ⌘W ⌘L</span></div>
          <div class="fetch-palette">
            <span style="background:var(--accent)"></span>
            <span style="background:var(--accent-strong)"></span>
            <span style="background:var(--accent-soft)"></span>
            <span style="background:var(--glass-border-bright)"></span>
            <span style="background:var(--text-primary)"></span>
          </div>
        </div>
      </div>`;

    withdrawActiveViewForOverlay();
    document.getElementById("about-overlay").classList.add("show");
    document.getElementById("about-panel").classList.add("show");
  }

  function closeAbout() {
    document.getElementById("about-overlay").classList.remove("show");
    document.getElementById("about-panel").classList.remove("show");
    restoreActiveViewFromOverlay();
  }

  function wireAbout() {
    document.getElementById("brand-btn").addEventListener("click", openAbout);
    document.getElementById("about-close").addEventListener("click", closeAbout);
    document.getElementById("about-overlay").addEventListener("click", closeAbout);
  }

  // ---------- Wiring ----------

  function wireUI() {
    document.getElementById("addr-form").addEventListener("submit", (e) => {
      e.preventDefault();
      navigate(document.getElementById("addr-input").value);
    });
    document.getElementById("start-form").addEventListener("submit", (e) => {
      e.preventDefault();
      navigate(document.getElementById("start-addr-input").value);
    });
    wireSuggestions(
      document.getElementById("addr-input"),
      document.getElementById("addr-suggest"),
      document.getElementById("addr-form")
    );
    wireSuggestions(
      document.getElementById("start-addr-input"),
      document.getElementById("start-addr-suggest"),
      document.getElementById("start-form")
    );

    const addrInput = document.getElementById("addr-input");
    const addrClear = document.getElementById("addr-clear");
    addrInput.addEventListener("input", () => {
      addrClear.classList.toggle("show", addrInput.value.length > 0);
    });
    addrClear.addEventListener("click", () => {
      addrInput.value = "";
      addrClear.classList.remove("show");
      addrInput.focus();
    });
    addrInput.addEventListener("focus", withdrawActiveViewForOverlay);
    addrInput.addEventListener("blur", () => setTimeout(restoreActiveViewFromOverlay, 200));

    document.getElementById("new-tab-btn").addEventListener("click", () => createTab(null));

    document.getElementById("back-btn").addEventListener("click", () => {
      const tab = currentTab();
      if (!tab) return;
      if (isTauri) {
        tauriInvoke("tab_eval", { id: tab.id, script: "window.history.back();" }).catch(() => {});
        return;
      }
      const f = document.getElementById(`frame-${tab.id}`);
      if (!f) return;
      try { f.contentWindow?.history.back(); } catch {}
      f.classList.remove("nav-back");
      void f.offsetWidth;
      f.classList.add("nav-back");
    });
    document.getElementById("fwd-btn").addEventListener("click", () => {
      const tab = currentTab();
      if (!tab) return;
      if (isTauri) {
        tauriInvoke("tab_eval", { id: tab.id, script: "window.history.forward();" }).catch(() => {});
        return;
      }
      const f = document.getElementById(`frame-${tab.id}`);
      if (!f) return;
      try { f.contentWindow?.history.forward(); } catch {}
      f.classList.remove("nav-fwd");
      void f.offsetWidth;
      f.classList.add("nav-fwd");
    });
    document.getElementById("reload-btn").addEventListener("click", () => {
      const btn = document.getElementById("reload-btn");
      btn.classList.remove("kick");
      void btn.offsetWidth;
      btn.classList.add("kick");
      setTimeout(() => btn.classList.remove("kick"), 300);

      const tab = currentTab();
      if (!tab || tab.url === "about:start") return;
      if (isTauri) {
        btn.classList.add("loading");
        tauriInvoke("tab_eval", { id: tab.id, script: "window.location.reload();" }).catch(() => {});
        setTimeout(() => btn.classList.remove("loading"), 1200);
        return;
      }
      const f = document.getElementById(`frame-${tab.id}`);
      if (f) {
        btn.classList.add("loading");
        f.src = f.src;
        setTimeout(() => btn.classList.remove("loading"), 6000);
      }
    });
    document.getElementById("open-system-btn").addEventListener("click", () => {
      const tab = currentTab();
      if (tab && tab.url !== "about:start") openInSystemBrowser(tab.url);
    });

    document.getElementById("sidebar-collapse").addEventListener("click", () => {
      document.getElementById("shell").classList.toggle("collapsed");
    });

    // Settings is wired up by Settings.init(). Ensure native tab view is
    // withdrawn before opening, and restored after closing so overlays
    // reliably appear above content (native webviews otherwise paint on top).
    document.getElementById("settings-btn").addEventListener("click", () => {
      withdrawActiveViewForOverlay();
      // Small delay gives the native view time to hide before showing the panel
      setTimeout(() => Settings.openPanel(), 60);
    });
    document.getElementById("settings-close").addEventListener("click", () => {
      Settings.closePanel();
      restoreActiveViewFromOverlay();
    });
    document.getElementById("settings-overlay").addEventListener("click", () => {
      Settings.closePanel();
      restoreActiveViewFromOverlay();
    });

    wireCmdk();
    wireAbout();

    if (isTauri) {
      // Keep the active tab's native webview aligned with the content
      // area across window resizes and sidebar collapse/expand.
      let boundsTimer = null;
      const ro = new ResizeObserver(() => {
        if (!activeNativeTabId) return;
        clearTimeout(boundsTimer);
        boundsTimer = setTimeout(() => {
          tauriInvoke("set_tab_bounds", { id: activeNativeTabId, ...getViewBounds() }).catch(() => {});
        }, 16);
      });
      ro.observe(document.getElementById("view-stack"));
    }

    document.addEventListener("keydown", (e) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); openCmdk(); return; }
      if (e.key === "Escape") { closeCmdk(); closeAbout(); }
      if (!mod) return;
      if (e.key.toLowerCase() === "t") { e.preventDefault(); createTab(null); }
      else if (e.key.toLowerCase() === "w") { e.preventDefault(); const t = currentTab(); if (t) closeTab(t.id); }
      else if (e.key.toLowerCase() === "l") { e.preventDefault(); document.getElementById("addr-input").focus(); document.getElementById("addr-input").select(); }
    });

    window.addEventListener("resize", updateTabIndicator);

    // A subtle "wobble" whenever the native window is dragged, so moving
    // the window feels alive rather than static. Only available inside
    // the real Tauri app (no-op in the plain-browser preview).
    if (isTauri) {
      try {
        const wm = window.__TAURI__.window;
        const win = (wm.getCurrentWindow || wm.getCurrent)?.call(wm);
        let wobbleTimer = null;
        win?.onMoved?.(() => {
          const shell = document.getElementById("shell");
          shell.classList.remove("wobble");
          void shell.offsetWidth;
          shell.classList.add("wobble");
          clearTimeout(wobbleTimer);
          wobbleTimer = setTimeout(() => shell.classList.remove("wobble"), 340);
        });
      } catch (err) {
        console.warn("Window move animation unavailable:", err);
      }
    }

    wireVaultAndHistory();
    wireDraggableButtons();
  }

  // ---------------------------------------------------------------------
  // Passwords + History panels (inside Settings)
  // ---------------------------------------------------------------------
  function renderVaultList() {
    const el = document.getElementById("vault-list");
    if (!el) return;
    const entries = Vault.list();
    el.innerHTML = entries.length
      ? entries.map((e, i) => `
        <div class="vault-row" data-i="${i}">
          <div class="vault-row-main">
            <strong>${escapeHtml(e.site)}</strong>
            <span>${escapeHtml(e.username)}</span>
          </div>
          <div class="vault-row-actions">
            <button class="icon-btn vault-copy" data-copy="${escapeHtml(e.password)}" title="Copy password">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
            </button>
            <button class="icon-btn vault-del" data-site="${escapeHtml(e.site)}" data-user="${escapeHtml(e.username)}" title="Delete">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0l-1 14a2 2 0 01-2 2H7a2 2 0 01-2-2L4 6"/></svg>
            </button>
          </div>
        </div>`).join("")
      : `<p class="field-hint">No saved logins yet — add one below.</p>`;

    el.querySelectorAll(".vault-copy").forEach((btn) => {
      btn.addEventListener("click", () => {
        navigator.clipboard?.writeText(btn.dataset.copy || "").catch(() => {});
        btn.classList.add("copied");
        setTimeout(() => btn.classList.remove("copied"), 900);
      });
    });
    el.querySelectorAll(".vault-del").forEach((btn) => {
      btn.addEventListener("click", () => {
        Vault.remove(btn.dataset.site, btn.dataset.user);
        renderVaultList();
      });
    });
  }

  function renderHistoryList() {
    const el = document.getElementById("history-list");
    if (!el) return;
    const entries = HistoryStore.list();
    el.innerHTML = entries.length
      ? entries.slice(0, 200).map((e) => `
        <div class="history-row" data-time="${e.time}">
          <div class="history-row-main">
            <strong>${escapeHtml(e.title)}</strong>
            <span>${escapeHtml(e.url)}</span>
          </div>
          <button class="icon-btn history-del" data-time="${e.time}" title="Remove">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>`).join("")
      : `<p class="field-hint">No browsing history yet.</p>`;

    el.querySelectorAll(".history-row-main").forEach((row, i) => {
      row.addEventListener("click", () => {
        const entry = entries[i];
        if (!entry) return;
        Settings.closePanel();
        restoreActiveViewFromOverlay();
        createTab(entry.url);
      });
    });
    el.querySelectorAll(".history-del").forEach((btn) => {
      btn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        HistoryStore.remove(Number(btn.dataset.time));
        renderHistoryList();
      });
    });
  }

  function wireVaultAndHistory() {
    renderVaultList();
    renderHistoryList();

    const form = document.getElementById("vault-add-form");
    form?.addEventListener("submit", (e) => {
      e.preventDefault();
      const site = document.getElementById("vault-site").value.trim();
      const user = document.getElementById("vault-user").value.trim();
      const pass = document.getElementById("vault-pass").value;
      if (!site || !user || !pass) return;
      Vault.add(site, user, pass);
      form.reset();
      renderVaultList();
    });

    document.getElementById("history-clear")?.addEventListener("click", () => {
      HistoryStore.clear();
      renderHistoryList();
    });
  }

  // ---------------------------------------------------------------------
  // Customizable layout — every toolbar / sidebar-footer icon button can
  // be picked up and dropped into a new order. Order persists in
  // localStorage per container id, keyed by each button's element id so
  // it survives reloads.
  // ---------------------------------------------------------------------
  function wireDraggableButtons() {
    const containers = [
      document.getElementById("nav-group"),
      document.getElementById("sidebar-footer"),
    ].filter(Boolean);

    containers.forEach((container) => {
      const key = `geo:layout:${container.id}`;
      // Restore saved order first.
      try {
        const order = JSON.parse(localStorage.getItem(key) || "null");
        if (Array.isArray(order)) {
          order.forEach((id) => {
            const node = document.getElementById(id);
            if (node) container.appendChild(node);
          });
        }
      } catch {}

      let dragEl = null;
      Array.from(container.children).forEach((child) => {
        if (!child.id) return;
        child.setAttribute("draggable", "true");
        child.classList.add("layout-draggable");
        child.addEventListener("dragstart", () => {
          dragEl = child;
          child.classList.add("dragging");
        });
        child.addEventListener("dragend", () => {
          child.classList.remove("dragging");
          dragEl = null;
          const order = Array.from(container.children).map((c) => c.id).filter(Boolean);
          localStorage.setItem(key, JSON.stringify(order));
        });
        child.addEventListener("dragover", (e) => {
          e.preventDefault();
          if (!dragEl || dragEl === child) return;
          const rect = child.getBoundingClientRect();
          const horizontal = container.id === "nav-group";
          const before = horizontal
            ? e.clientX < rect.left + rect.width / 2
            : e.clientY < rect.top + rect.height / 2;
          container.insertBefore(dragEl, before ? child : child.nextSibling);
        });
      });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    Settings.init();
    const restored = loadSession();
    renderWorkspaces();
    wireUI();
    if (restored) {
      const ws = activeWorkspace();
      renderTabs();
      renderActiveView();
    } else {
      createTab(null); // starts on the geo://start page
    }
  });
})();
