// Prevents an additional console window on Windows in release builds.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use std::collections::HashMap;
use std::sync::Mutex;

use tauri::{LogicalPosition, LogicalSize, Url, WebviewUrl};

/// Registry of the native per-tab webviews Geo creates on top of the
/// main window's content area, keyed by the JS-side tab id ("t1",
/// "t2", ...). The frontend creates/moves/shows/hides/closes these by
/// id — it never needs to know Tauri's own webview labels.
///
/// This is the fix for pages refusing to load: previously every tab
/// was an <iframe> inside Geo's own single WebView, and most real
/// sites (Google, search results, anything with X-Frame-Options or a
/// CSP frame-ancestors policy) refuse to render *inside another
/// page's iframe* — that's what those headers are for. A native child
/// webview isn't an iframe embed at all; it's a real top-level
/// navigation done by the OS's own browser engine, exactly like a
/// normal browser tab, so those headers don't come into play.
#[derive(Default)]
struct TabViews(Mutex<HashMap<String, tauri::Webview>>);

fn label_for(id: &str) -> String {
    format!("tabview-{id}")
}

/// Creates the native webview for a tab, positioned/sized to match the
/// on-screen content area, and points it at `url`. No-op if a view for
/// this id already exists (use `navigate_tab_view` to change its URL).
#[tauri::command]
fn create_tab_view(
    window: tauri::Window,
    state: tauri::State<TabViews>,
    id: String,
    url: String,
    x: f64,
    y: f64,
    width: f64,
    height: f64,
) -> Result<(), String> {
    let mut views = state.0.lock().map_err(|e| e.to_string())?;
    if views.contains_key(&id) {
        return Ok(());
    }
    let parsed = Url::parse(&url).map_err(|e| e.to_string())?;
    let builder =
        tauri::webview::WebviewBuilder::new(label_for(&id), WebviewUrl::External(parsed));
    let webview = window
        .add_child(
            builder,
            LogicalPosition::new(x, y),
            LogicalSize::new(width, height),
        )
        .map_err(|e| e.to_string())?;
    views.insert(id, webview);
    Ok(())
}

/// Navigates an existing tab's webview to a new URL, preserving that
/// webview's own back/forward history (unlike the old iframe build,
/// which threw the frame away and recreated it on every navigation).
#[tauri::command]
fn navigate_tab_view(state: tauri::State<TabViews>, id: String, url: String) -> Result<(), String> {
    let views = state.0.lock().map_err(|e| e.to_string())?;
    let webview = views.get(&id).ok_or("no such tab view")?;
    let js_url = serde_json::to_string(&url).map_err(|e| e.to_string())?;
    webview
        .eval(&format!("window.location.href = {js_url};"))
        .map_err(|e| e.to_string())
}

/// Repositions/resizes a tab's webview to match the current content
/// area (called on window resize and sidebar collapse/expand).
#[tauri::command]
fn set_tab_bounds(
    state: tauri::State<TabViews>,
    id: String,
    x: f64,
    y: f64,
    width: f64,
    height: f64,
) -> Result<(), String> {
    let views = state.0.lock().map_err(|e| e.to_string())?;
    let webview = views.get(&id).ok_or("no such tab view")?;
    webview
        .set_position(LogicalPosition::new(x, y))
        .map_err(|e| e.to_string())?;
    webview
        .set_size(LogicalSize::new(width, height))
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn show_tab_view(state: tauri::State<TabViews>, id: String) -> Result<(), String> {
    let views = state.0.lock().map_err(|e| e.to_string())?;
    match views.get(&id) {
        Some(w) => w.show().map_err(|e| e.to_string()),
        None => Ok(()),
    }
}

/// Hides (does not close) a tab's webview — used both when switching
/// tabs and whenever Geo's own UI needs to draw on top of the content
/// area (command palette, settings, the "About" panel, the address
/// bar while it has focus). Child webviews always render above the
/// app's own HTML, so those overlays would otherwise be drawn
/// underneath the active page.
#[tauri::command]
fn hide_tab_view(state: tauri::State<TabViews>, id: String) -> Result<(), String> {
    let views = state.0.lock().map_err(|e| e.to_string())?;
    match views.get(&id) {
        Some(w) => w.hide().map_err(|e| e.to_string()),
        None => Ok(()),
    }
}

#[tauri::command]
fn close_tab_view(state: tauri::State<TabViews>, id: String) -> Result<(), String> {
    let mut views = state.0.lock().map_err(|e| e.to_string())?;
    if let Some(w) = views.remove(&id) {
        w.close().map_err(|e| e.to_string())?;
    }
    Ok(())
}

/// Runs a small script inside a tab's webview — used for back/forward/
/// reload, which just drive that webview's own session history.
#[tauri::command]
fn tab_eval(state: tauri::State<TabViews>, id: String, script: String) -> Result<(), String> {
    let views = state.0.lock().map_err(|e| e.to_string())?;
    let webview = views.get(&id).ok_or("no such tab view")?;
    webview.eval(&script).map_err(|e| e.to_string())
}

/// Hands a URL to the user's default system browser instead of
/// trying to render it inside Geo's own embedded WebView. Kept as a
/// manual escape hatch (toolbar button / command palette) for the
/// rare page that still won't behave in an embedded engine.
#[tauri::command]
fn open_in_system_browser(url: String) -> Result<(), String> {
    if !(url.starts_with("http://") || url.starts_with("https://")) {
        return Err("Refusing to open a non-http(s) URL".into());
    }

    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open")
            .arg(&url)
            .spawn()
            .map_err(|e| e.to_string())?;
    }

    #[cfg(target_os = "windows")]
    {
        std::process::Command::new("cmd")
            .args(["/C", "start", "", &url])
            .spawn()
            .map_err(|e| e.to_string())?;
    }

    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open")
            .arg(&url)
            .spawn()
            .map_err(|e| e.to_string())?;
    }

    Ok(())
}

fn main() {
    tauri::Builder::default()
        .manage(TabViews::default())
        .invoke_handler(tauri::generate_handler![
            open_in_system_browser,
            create_tab_view,
            navigate_tab_view,
            set_tab_bounds,
            show_tab_view,
            hide_tab_view,
            close_tab_view,
            tab_eval,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Geo");
}
